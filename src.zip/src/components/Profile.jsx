import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "./Navbar";

function Profile() {
  const navigate = useNavigate();

  const user = {
    username: "Username",
    email: "youremail@gmail.com",
    sleepGoal: 8,
    waterGoal: 3000,
  };

  const [isEditing, setIsEditing] = useState(false);

  const [form, setForm] = useState({
    username: user.username,
    email: user.email,
    sleepGoal: user.sleepGoal,
    waterGoal: user.waterGoal,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };


  return (
    <div className="min-h-screen bg-[#D2EEFF] flex justify-center items-start md:items-center px-4 pb-12 md:pt-0">

      <div className="w-full max-w-5xl">

        {/* 📱 NAVBAR (MOBILE ONLY) */}
        <div className="block lg:hidden mb-4">
          <Navbar />
        </div>

        {/* 💻 HEADER (DESKTOP ONLY) */}
        <div className="hidden lg:flex items-center gap-2 mb-4">

          <button
            onClick={() => navigate("/dashboard")}
            className="text-sm text-[#0F3D5E] hover:underline"
          >
            ← Back to Dashboard
          </button>

          <span className="text-gray-400">|</span>

          <h1 className="text-2xl font-semibold text-gray-800">
            Profile
          </h1>

        </div>

        {/* 📱 TITLE (MOBILE ONLY) */}
        <h1 className="lg:hidden text-2xl text-center font-semibold text-gray-700 mb-4">
          Profile
        </h1>

        {/* AVATAR */}
        <div className="mb-6 flex justify-center lg:justify-start">
          <div className="w-20 h-20 md:w-24 md:h-24 bg-gray-200 rounded-full shadow-md"></div>
        </div>

        {/* USER INFO CARD */}
        <div className="bg-white/80 backdrop-blur rounded-2xl p-4 md:p-6 shadow-md mb-6">

          {!isEditing ? (
            <>
              {/* VIEW MODE */}
              <div className="mb-3 flex justify-between">
                <p className="text-gray-400 text-sm mb-1">Username</p>
                <div className="flex justify-between">
                  <span></span>
                  <p className="text-gray-600 text-sm">{user.username}</p>
                </div>
              </div>

              <hr className="border-[#B5B5B5] mb-3" />

              <div className="flex justify-between">
                <p className="text-gray-400 text-sm mb-1">Email</p>
                <div className="flex justify-between">
                  <span></span>
                  <p className="text-gray-600 text-sm break-all">{user.email}</p>
                </div>
              </div>
            </>
          ) : (
            <>
              {/* EDIT MODE */}
              <div className="mb-3">
                <p className="text-gray-400 text-sm mb-1">Username</p>
                <input
                  type="text"
                  name="username"
                  value={form.username}
                  onChange={handleChange}
                  className="w-full bg-blue-100 rounded-full px-4 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-300"
                />
              </div>

              <div>
                <p className="text-gray-400 text-sm mb-1">Email</p>
                <input
                  type="email"
                  name="email"
                  value={form.email}
                  onChange={handleChange}
                  className="w-full bg-blue-100 rounded-full px-4 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-300"
                />
              </div>
            </>
          )}

        </div>

        {/* GOALS CARD */}
        <div className="bg-white/80 backdrop-blur rounded-2xl p-4 md:p-6 shadow-md mb-8">

          <h2 className="text-center text-gray-500 mb-4 text-sm">
            Your Goals
          </h2>

          {!isEditing ? (
            <>
              <div className="mb-3 flex justify-between">
                <p className="text-gray-400 text-sm mb-1">Sleep Goal</p>
                <div className="flex justify-between">
                  <span></span>
                  <p className="text-gray-600 text-sm">
                    {user.sleepGoal || "__"} hours
                  </p>
                </div>
              </div>

              <hr className="border-[#B5B5B5] mb-3" />

              <div className="flex justify-between">
                <p className="text-gray-400 text-sm mb-1">Water Goal</p>
                <div className="flex justify-between">
                  <span></span>
                  <p className="text-gray-600 text-sm">
                    {user.waterGoal || "__"} ml
                  </p>
                </div>
              </div>
            </>
          ) : (
            <>
              <div className="mb-3">
                <p className="text-gray-400 text-sm mb-1">Sleep Goal</p>
                <input
                  type="number"
                  name="sleepGoal"
                  value={form.sleepGoal}
                  onChange={handleChange}
                  className="w-full bg-blue-100 rounded-full px-4 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-300"
                />
              </div>

              <div>
                <p className="text-gray-400 text-sm mb-1">Water Goal</p>
                <input
                  type="number"
                  name="waterGoal"
                  value={form.waterGoal}
                  onChange={handleChange}
                  className="w-full bg-blue-100 rounded-full px-4 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-300"
                />
              </div>
            </>
          )}

        </div>

        {/* BUTTONS */}
        <div className="flex flex-col items-center gap-2">

          <button
            onClick={() => setIsEditing(!isEditing)}
            className="bg-[#0F3D5E] text-white px-6 py-2 rounded-full text-sm shadow w-full md:w-auto"
          >
            {isEditing ? "Save" : "Edit Profile"}
          </button>

          <button
            onClick={() => navigate("/login")}
            className="text-gray-500 text-sm"
          >
            Logout
          </button>

        </div>

      </div>
    </div>
  );
}

export default Profile;